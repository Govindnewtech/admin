window.addEventListener('DOMContentLoaded', event => {
    // Toggle the side navigation
    const sidebarToggle = document.body.querySelector('#sidebarToggle');
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', event => {
            event.preventDefault();
            document.body.classList.toggle('sb-sidenav-toggled');
            localStorage.setItem('sb|sidebar-toggle', document.body.classList.contains('sb-sidenav-toggled'));
        });
    }

});


    // get data 

//   const userData ="http://192.168.1.69:8000/vender/all";
//     async function getapi(url) {
//         const response = await fetch(url);

//         var data = await response.json();

//         show(data);
//     }
//     getapi(userData);
//     function show(data) {
//         let tab =
//             `<thead>
//         <tr>
//           <th>No</th>
//           <th>Name</th>
//           <th>Store Name</th>
//           <th>Email</th>
//           <th>Phone</th>
//           <th>Address</th>
//           <th>Action</th>
//          </tr>
//          </thead>`;

//         // Loop to access all rows 
//    for (let r of data) {
//     tab += `<tbody><tr> 
//     <td>1</td>
//     <td>${r.name} </td>
//     <td>${r.storename}</td>
//     <td>${r.email}</td> 
//     <td>${r.phone}</td>  
//     <td>${r.address}</td>  
//     <td><button data-id="${r._id}" class="btn btn-primary form_value">Update</button>
//     <button delete-id="${r._id}" class="btn btn-danger delete_value">Delete</button></td>
// </tr></tbody>`;
//         }
     
//    document.getElementById("employees").innerHTML = tab;

//     }